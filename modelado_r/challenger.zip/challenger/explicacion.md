# Explicación línea por línea — Challenger MCMC

## Archivos

| Archivo | Método | Tasa aceptación |
|---|---|---|
| `challenger_independent.r` | M-H con propuestas independientes | ~3% |
| `challenger_random_walk.r` | M-H con random walk | ~12% |

---

## Sección común: Setup y Parte 1

Ambos archivos abren de la misma manera:

```r
lib <- path.expand("~/R/library")
```
Convierte `"~/R/library"` a la ruta absoluta del usuario (e.g. `/home/user/R/library`). Necesario porque R no siempre expande `~` solo.

```r
.libPaths(c(lib, .libPaths()))
```
Agrega la carpeta de usuario al frente del vector de directorios donde R busca paquetes. Sin esto, `library(mcsm)` no lo encuentra porque fue instalado fuera del path del sistema.

```r
library(mcsm)
data(challenger)
```
Carga el paquete `mcsm` (Monte Carlo Statistical Methods) y el dataset `challenger` en el entorno global. El dataset tiene 23 filas y 2 columnas: `oring` (0/1) y `temp` (°F).

```r
fit <- glm(oring ~ temp, data = challenger, family = binomial(link = "logit"))
```
Ajusta una regresión logística. `glm` = Generalized Linear Model. `family = binomial(link = "logit")` especifica que la variable respuesta es binaria y que el link es la función logit: `log(p/(1-p)) = α + β*x`.

```r
summary(fit)
```
Imprime los coeficientes estimados, errores estándar, z-values y p-values del modelo.

```r
alpha_mle <- coef(fit)[1]
beta_mle  <- coef(fit)[2]
```
Extrae los MLE (Maximum Likelihood Estimators): `coef(fit)[1]` es el intercepto α ≈ 15.04, `coef(fit)[2]` es la pendiente β ≈ -0.232.

```r
se_alpha <- summary(fit)$coefficients[1, 2]
se_beta  <- summary(fit)$coefficients[2, 2]
```
Extrae los errores estándar de cada coeficiente. La columna 2 de la matriz de coeficientes contiene los SE. Se usan para parametrizar las distribuciones candidatas del M-H.

---

## Funciones auxiliares (ambos archivos)

```r
rlaplace <- function(n, mu = 0, b = 1) {
  u <- runif(n, -0.5, 0.5)
  mu - b * sign(u) * log(1 - 2 * abs(u))
}
```
Generador de la distribución Laplace (doble exponencial) usando el método de inversión de la CDF. `runif` genera uniformes en (-0.5, 0.5), luego se aplica la función cuantil de la Laplace: `F^{-1}(u) = μ - b·sign(u)·log(1 - 2|u|)`. La Laplace tiene colas más pesadas que la normal, útil para proponer saltos grandes.

```r
dlaplace <- function(x, mu = 0, b = 1, log = FALSE) {
  val <- -log(2 * b) - abs(x - mu) / b
  if (log) val else exp(val)
}
```
Densidad de la Laplace: `f(x) = (1/2b) * exp(-|x-μ|/b)`. Se calcula en escala logarítmica (`-log(2b) - |x-μ|/b`) para estabilidad numérica. El argumento `log = TRUE` la devuelve en log-escala, necesario para el ratio de M-H. Solo existe en `challenger_independent.r` porque el random walk usa propuestas simétricas que se cancelan en el ratio.

```r
log_lik <- function(a, b, datos) {
  p <- plogis(a + b * datos$temp)
  p <- pmax(pmin(p, 1 - 1e-10), 1e-10)
  sum(datos$oring * log(p) + (1 - datos$oring) * log(1 - p))
}
```
Log-verosimilitud del modelo logístico. `plogis(x) = exp(x)/(1+exp(x))` es la función logística inversa. `pmax`/`pmin` limita `p` a [1e-10, 1-1e-10] para evitar `log(0) = -Inf`. La fórmula es la log-verosimilitud de Bernoulli: `Σ [y·log(p) + (1-y)·log(1-p)]`.

---

## Parte 2: Diferencia clave entre los dos archivos

### `challenger_independent.r` — Propuestas independientes

```r
mh_independent <- function(Nsim = 5000, datos, a0, b0, se_b) {
```
La función recibe el número de iteraciones, los datos, valores iniciales `a0`, `b0`, y el SE de β (`se_b`). No necesita `se_a` porque el rate de la exponencial se deriva de `a0` directamente.

```r
  rate_a  <- 1 / a0
  scale_b <- abs(se_b)
```
Parámetros de los candidatos. `rate_a = 1/α_MLE` da una exponencial con media igual al MLE de α (~15). `scale_b = |SE_β|` da una Laplace con dispersión calibrada al error estándar de β.

```r
    a_star <- rexp(1, rate = rate_a)
    b_star <- rlaplace(1, mu = b0, b = scale_b)
```
**Propuesta independiente**: propone `α*` directamente desde `Exp(rate_a)` y `β*` desde `Laplace(β_MLE, SE_β)`. No depende del valor actual de la cadena — cada propuesta parte de cero.

```r
    log_r <- log_lik(a_star, b_star, datos) - log_lik(alpha[t-1], beta[t-1], datos) +
             dexp(alpha[t-1],    rate = rate_a,  log = TRUE) - dexp(a_star, rate = rate_a,  log = TRUE) +
             dlaplace(beta[t-1], mu = b0, b = scale_b, log = TRUE) - dlaplace(b_star, mu = b0, b = scale_b, log = TRUE)
```
Ratio de Metropolis-Hastings completo: `log[π(θ*)/π(θ)] + log[q(θ|θ*)/q(θ*|θ)]`. Con propuestas independientes las densidades candidatas NO se cancelan, por eso se incluyen los términos `dexp` y `dlaplace`. Esto penaliza propuestas en regiones de baja densidad candidata.

---

### `challenger_random_walk.r` — Random walk

```r
mh_random_walk <- function(Nsim = 5000, datos, a0, b0, se_a, se_b) {
```
Recibe también `se_a` (SE de α) para calibrar el tamaño del paso.

```r
  step_a <- se_a * 0.5
  step_b <- se_b * 0.5
```
Tamaños de paso = la mitad del error estándar. Más pequeño = más aceptaciones pero exploración más lenta. Más grande = menos aceptaciones pero saltos más amplios. El factor 0.5 es un balance empírico para obtener ~10-30% de aceptación.

```r
    eps_a  <- rexp(1, rate = 1 / step_a) * sample(c(-1, 1), 1)
    a_star <- alpha[t-1] + eps_a
```
Paso exponencial con signo aleatorio: genera un incremento `ε ~ Exp(1/step_a)` y le asigna signo + o - con igual probabilidad. Esto hace la propuesta simétrica alrededor del valor actual, manteniendo α positivo en la mayoría de casos.

```r
    b_star <- rlaplace(1, mu = beta[t-1], b = step_b)
```
Paso Laplace centrado en el valor **actual** de β (no en el MLE). Esto es el random walk: la propuesta se mueve alrededor de donde está la cadena ahora.

```r
    if (a_star > 0) {
      log_r <- log_lik(a_star, b_star, datos) - log_lik(alpha[t-1], beta[t-1], datos)
    } else {
      log_r <- -Inf
    }
```
Con propuestas simétricas `q(θ*|θ) = q(θ|θ*)`, los términos candidatos se cancelan y el ratio se reduce solo a la diferencia de log-verosimilitudes. Si `α* ≤ 0` se rechaza automáticamente (`-Inf` garantiza rechazo porque `log(runif) > -Inf` siempre).

---

## Sección común: Parte 3 — Gráficos

```r
set.seed(42)
chain <- mh_...(5000, challenger, ...)
```
`set.seed(42)` fija la semilla para reproducibilidad. La función retorna una lista con los vectores `alpha` y `beta` de longitud 5000.

```r
png("challenger/..._trace.png", width = 800, height = 500)
par(mfrow = c(2, 1), mar = c(4, 4, 2, 1))
```
Abre el dispositivo PNG para guardar. `mfrow = c(2,1)` divide la ventana en 2 filas, 1 columna. `mar` reduce los márgenes para aprovechar el espacio.

```r
plot(chain$alpha, type = "l", col = "steelblue", ...)
abline(h = alpha_mle, col = "red", lty = 2, lwd = 1.5)
```
Trace plot de α: cada iteración en el eje X, el valor de α en el eje Y. Una cadena bien mezclada oscila rápidamente alrededor del MLE (línea roja). El trace del independiente muestra escalones (se queda fijo muchas iteraciones), el random walk muestra deriva más continua.

```r
temps   <- seq(50, 85, by = 0.5)
p_mat   <- plogis(outer(chain$alpha, rep(1, length(temps))) + outer(chain$beta, temps))
```
Grilla de 71 temperaturas entre 50 y 85°F. `outer` calcula el producto externo: `p_mat[i,j] = plogis(alpha[i] + beta[i] * temps[j])`, resultando en una matriz de 5000×71 con la curva logística de cada iteración.

```r
p_mean  <- colMeans(p_mat)
p_lower <- apply(p_mat, 2, quantile, 0.025)
p_upper <- apply(p_mat, 2, quantile, 0.975)
```
Resumen posterior: media y percentiles 2.5%/97.5% por columna (por temperatura). Se usan para referencias numéricas aunque el gráfico principal usa curvas individuales.

```r
idx_last <- (length(chain$alpha) - 499):length(chain$alpha)
```
Índices de las últimas 500 iteraciones (de 4501 a 5000). Al igual que la Figura 6.6, se grafican las últimas 500 curvas para mostrar la variabilidad posterior sin burn-in.

```r
plot(temps, p_mat[idx_last[1], ], type = "l", col = "gray80", lwd = 0.5, ...)
for (i in idx_last[-1]) lines(temps, p_mat[i, ], col = "gray80", lwd = 0.5)
```
Dibuja la primera curva gris como base del plot, luego agrega las 499 restantes encima. Cada línea gris es una curva logística `p(x) = logistic(α^(i) + β^(i)·x)` de una iteración del chain. La dispersión de las curvas refleja la incertidumbre posterior.

```r
lines(temps, p_mean, col = "red", lwd = 2)
points(challenger$temp, challenger$oring, pch = 19, col = "black")
```
Dibuja la media posterior en rojo (equivalente a la curva oscura de la Fig. 6.6) y superpone los puntos observados. Los puntos van al final para que queden visibles encima de las curvas.

---

## Parte 4: Estimación puntual

```r
for (temp in c(60, 50, 40)) {
  p_vals <- plogis(chain$alpha + chain$beta * temp)
  cat(sprintf("T = %d F:  P(falla) = %.4f  +-  %.4f\n", temp, mean(p_vals), sd(p_vals)))
}
```
Para cada temperatura de interés, calcula el vector de 5000 probabilidades usando todos los pares `(α^(i), β^(i))` de la cadena. `mean(p_vals)` es la estimación puntual posterior y `sd(p_vals)` es el error estándar Monte Carlo. Cuanto mejor mezcle la cadena, más confiable es el estimado.

---

## Comparación de resultados

| | Independiente | Random Walk |
|---|---|---|
| Tasa aceptación | ~3% | ~12% |
| Trace plot | Escalones largos (se "pega") | Deriva continua |
| Curvas grises | Pocas curvas distintas (baja diversidad) | Muchas curvas distintas (mejor cobertura) |
| P(falla) 60°F | 0.749 ± 0.156 | 0.797 ± 0.148 |
| P(falla) 50°F | 0.938 ± 0.097 | 0.960 ± 0.070 |
| P(falla) 40°F | 0.980 ± 0.057 | 0.990 ± 0.033 |

El random walk explora mejor el espacio posterior → menores errores estándar y curvas más densas en el gráfico. El independiente tiene baja tasa de aceptación porque la exponencial propone valores lejos de la región de alta verosimilitud con frecuencia.
